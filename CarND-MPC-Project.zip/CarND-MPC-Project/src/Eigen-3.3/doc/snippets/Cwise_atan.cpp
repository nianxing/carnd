ArrayXd v = ArrayXd::LinSpaced(5,0,1);
cout << v.atan() << endl;
